### telegram-desktop

Telegram application qube, served over the Tor network. With the template you may clone additional appvms (qubes) and use separate accounts simultaneously.

```
sudo qubesctl --targets=tpl-telegram state.apply qujourno.telegram.create
```

Credit: [Leo](https://forum.qubes-os.org/t/qubes-salt-beginners-guide/20126)
