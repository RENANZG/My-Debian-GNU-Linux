# journo-qubes-task
*This is a work-in-progress. I anticipate the salt files to be completed first, then RPM packages, and lastly this manager*
Journalist-specific QubesOS task-manager, modified from [unman's](https://github.com/unman/qubes-task) own.
