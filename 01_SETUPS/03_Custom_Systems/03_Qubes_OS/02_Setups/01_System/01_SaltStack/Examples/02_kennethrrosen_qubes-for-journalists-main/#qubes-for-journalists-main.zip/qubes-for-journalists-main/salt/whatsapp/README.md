### whatsapp (whatsdesk)

Creates a WhatsApp qube and templates, served over the Tor network, allowing you to create multiple instances and numbers if you have seperate numbers for work, personal, and sources.

```
sudo qubesctl --targets=whatsapp,tpl-whatsapp state.apply qujourno.whatsapp.create
```
