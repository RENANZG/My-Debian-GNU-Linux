### proton-mail

Installs a Proton Mail qube (accounts are free), for exchanging end-to-end encrypted email that not even the provider has access to. 

This application is served over the Tor network.

```
sudo qubesctl --targets=proton-mail state.apply qujourno.proton-mail.create
```
