### Securedrop journalist viewer

Work-in-progress: A tunnel to the securedrop journalists viewing station. **IMPORTANT:** The admin will have to modify this script locally to ammend the tor link to the journalist login page for their [securedrop](https://securedrop.org/) instance.

```
```
