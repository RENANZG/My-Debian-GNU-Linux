### proton-vpn

Installs a ProtonVPN qube (accounts are free) to which other VMs can be connected; potentially your default-disposable or an unsafe browsing qube.

This application is served over the Tor network.

```
sudo qubesctl --targets=proton-vpn state.apply qujourno.proton-vpn.create
```
