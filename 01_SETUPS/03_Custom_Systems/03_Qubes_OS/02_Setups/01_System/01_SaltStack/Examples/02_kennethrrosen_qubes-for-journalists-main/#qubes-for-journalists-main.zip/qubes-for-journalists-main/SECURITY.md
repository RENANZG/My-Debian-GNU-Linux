# Security Policy

## Reporting a Vulnerability

To report a vulnerability, create a pull request or send an email to kennethrrosen@proton.me
