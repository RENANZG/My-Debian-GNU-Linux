===================
my-qubes-os-formula
===================

0.2.0 (2018-06-13)

- Add new states
- Improve some states
- Remove work environments
- Use if statements, loops and variables when needed

0.1.0 (2017-08-18)

- Initial version
