# utils

Utilities library for Qusal.

## Table of Contents

*   [Description](#description)
*   [Usage](#usage)

## Description

Utils is a SaltStack Qubes library for certain operations shared by multiple
projects such as macros and common tools to be installed.

## Usage

You are not meant to interact with the utils directly, but through other
states.
