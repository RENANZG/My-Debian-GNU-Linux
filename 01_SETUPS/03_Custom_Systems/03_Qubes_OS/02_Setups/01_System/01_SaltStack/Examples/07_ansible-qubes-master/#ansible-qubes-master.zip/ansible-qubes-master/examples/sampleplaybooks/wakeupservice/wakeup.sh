#!/bin/bash

echo "I ran after suspend/hibernate"
