# qubes-conky
Conky script for showing system info in Qubes OS

![conky-small](https://github.com/renehoj/qubes-conky/assets/108547507/517f0f9b-a571-434f-a101-bb9d25d811b2)
