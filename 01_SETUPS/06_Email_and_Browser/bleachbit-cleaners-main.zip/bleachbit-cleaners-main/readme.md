Librewolf, MidoriNG, Brave, Brave Nightly  cleaners for Bleachbit

put it in ~/.config/bleachbit/cleaners/

Not tested in Windows.
