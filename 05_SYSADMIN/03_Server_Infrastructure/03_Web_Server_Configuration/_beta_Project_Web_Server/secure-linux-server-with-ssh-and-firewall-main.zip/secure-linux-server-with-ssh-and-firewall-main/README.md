# secure-linux-server-with-ssh-and-firewall
Target is to secure any Linux Server with proper set of ssh configuration &amp; by adding a feature rich firewall
