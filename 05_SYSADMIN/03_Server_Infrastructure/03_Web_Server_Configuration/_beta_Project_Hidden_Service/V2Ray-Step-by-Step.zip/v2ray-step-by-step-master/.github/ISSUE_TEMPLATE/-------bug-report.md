---
name: 问题报告 / bug report
about: Create a report to help us improve
title: "[bug] "
labels: bug, unconfirmed
assignees: ''

---

## 与 bug 有关的页面 / related page
[???.md](../blob/transifex/zh_CN/???.md)

## bug 描述 / description of the bug
在此描述出现的问题。

## 复现步骤 / how we can reproduce
在此描述复现出现的问题所需的步骤和环境。
