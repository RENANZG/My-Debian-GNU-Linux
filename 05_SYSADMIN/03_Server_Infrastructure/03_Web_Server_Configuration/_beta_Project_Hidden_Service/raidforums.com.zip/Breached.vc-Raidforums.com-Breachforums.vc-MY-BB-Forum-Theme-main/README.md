### ⚠️ Breachforums.vc is down, Please make a clone so the feds won't win. You can use the official breachforums.vc Hidden Service (Tor) Onion Link: http://breachedu76kdyavc6szj6ppbplfqoz3pgrk3zw57my4vybgblpfeayd.onion ⚠️

# Breached.vc-Raidforums.com-Breachforums.vc-MY-BB-Forum-Theme
The infamous Raidforums.com MyBB Theme. (Ripped by @xbdmHQ)

### How to rip any mybb forum (method 1):
```
1. Choose a MyBB Forum
2. Right Click and select "View Page Source"
3. Press CTRL+F and search for ".css"
4. You will be shown a global.css file link.
5. Select and Open it,
6. Copy the entire code into a notepad.
7. In some lines you will see something like: (..../images/theme/header.png). Just replace those dots with the website URL for which u are ripping.  Do this for all the lines that contains dots.
8. Done!

You have finished the ripping. Theme is ready.
1. Now Go to your MyBB Forum and navigate to:
2. AdminCP>Templates and styles>Themes>Create new theme>Name it> Global.CSS> Advanced Mode>
3. Copy and Paste the code here and save it. Done!
```

### How to rip any mybb forum (method 2):

Chrome Extension
```
https://chrome.google.com/webstore/detail/save-all-resources/abpdnfjocnmdomablahdcfnoggeeiedb
```

Firefox Extension
```
https://addons.mozilla.org/en-US/firefox/addon/download-all-sources/
https://addons.mozilla.org/en-US/firefox/addon/save-page-we/
https://addons.mozilla.org/en-US/firefox/addon/save-all-files/
https://addons.mozilla.org/en-US/firefox/addon/downthemall/
https://addons.mozilla.org/en-US/firefox/addon/simple-mass-downloader/
```

### Unminified .css
```
https://tylerbockler.medium.com/unminify-code-using-chrome-developer-tools-52a52b458545
```
