#! /usr/bin/env python

"""Convenience wrapper for running vanguards directly from source tree."""

import vanguards.main

if __name__ == '__main__':
    vanguards.main.main()
