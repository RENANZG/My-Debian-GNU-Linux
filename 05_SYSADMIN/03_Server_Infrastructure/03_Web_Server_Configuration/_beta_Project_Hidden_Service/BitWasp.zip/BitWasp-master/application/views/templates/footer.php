      </div> <!-- /row-fluid -->
      <hr />
    <footer>
	<p class="pull-right">Page rendered in <strong>{elapsed_time}</strong> seconds. <a href="https://github.com/Bit-Wasp/BitWasp">Powered by BitWasp</a></p>
    </footer>
    </div>  <!-- /container -->
    <!--
    # Javascript is removed at the moment.
    <script src="<?php echo base_url(); ?>assets/js/jquery-1.8.1.min.js"></script>
    <script src="<?php echo base_url(); ?>assets/js/bootstrap.min.js"></script>-->
  </body>
</html>
