	<div id="item_view" class="mainContent">
	<?php if(isset($returnMessage)) echo $returnMessage; ?>

	</div>
