        <div class="span3">
          <div class="well sidebar-nav">
            <ul class="nav nav-list">
              <li class="nav-header">Categories</li>
              <?php echo $cats ?>
            </ul>
          </div>
        </div>
