        <div class="span9 mainContent" id="homepage">
          <h2>Welcome!</h2>
          <p>You are using Bitwasp!<p>
          <p>This is a developmental instance, and is not really for selling anything.</p>
          <p><strong>However</strong> we would appreciate if you would register an account, leave a few clicks, and let us know what you think! We are intending this to be the best open source marketplace for tor hidden services, and know that we will benefit from your feedback and experience.</p>
          <p>To create some new categories, login as the 'admin', password is 'admin'.</p>

          <ul>
            <li><a href='http://thelaboratory.org'>Project Homepage</a></li>
            <li><a href='http://github.com/Bit-Wasp/BitWasp'>github</a></li>
            <li><a href='https://www.facebook.com/pages/BitWasp-Anonymous-Open-Source-Bitcoin-Marketplace/404638142925188'>facebook</a></li>
            <li><a href='https://plus.google.com/109479781028317238648'>google+</a></li>
            <li><a href='https://twitter.com/bitwasp'>twitter</a></li>
          </ul>
          <?php echo anchor('items','View Items', 'class="btn-primary btn"');?>
        </div>
