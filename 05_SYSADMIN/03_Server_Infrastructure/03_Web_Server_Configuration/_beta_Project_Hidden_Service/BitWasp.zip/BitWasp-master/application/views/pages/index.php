<h2><?php echo $title; ?></h2>
<?php echo $content; ?>
