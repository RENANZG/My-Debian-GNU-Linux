#What is BitWasp
BitWasp is an open source project which aims to lower the barrier for anyone to set up there own secure, anonymous marketplace. It is envisaged that BitWasp may be used on Tor hidden services. As such it is designed with speed in mind. This project will also eventually full integrate with BitCoin providing a secure escrow service for buyers and sellers. This project is still in its very early stages. There is a preliminary planning document at https://piratenpad.de/p/bitwasp-planning

If you can help or have any ideas please join us on http://www.thelaboratory.org

#WARNING - BitWasp is NOT production ready
This project is very much under development and we have not yet made a beta release. Please be aware that this project has not yet
undergone extensive security testing and the code base is still missiing a number of key features. Please download and test the code
by all means but we would strongly recommend it is not deployed on a production system. We will update this README when there is a beta release. 

#Installation and Configuration
To set up BitWasp, first make ./application/config and ./assets/images writable.

chmod 777 ./application/config
chmod 777 -R ./assets/images

And then visit the installer page to set up the marketplace.

# Support Bitwasp Development
All money from donations, supporter and sponsor accounts go to fund BitWasp Development & Operation. 
Bitcoin Address: 19wXXScUGcpTUZUYo4kaevoLZKczE8G7q

All help and contributions in getting Bitwasp completed are very much appreciated as the time of the lead developers is currently very limited.

